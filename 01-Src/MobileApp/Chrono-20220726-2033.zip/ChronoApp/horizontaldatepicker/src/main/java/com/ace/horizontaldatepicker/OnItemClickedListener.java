package com.ace.horizontaldatepicker;

import android.view.View;

public interface OnItemClickedListener
{
    void onClickView( View v, int adapterPosition );
}