package com.ace.horizontaldatepicker;

import org.joda.time.DateTime;

public interface DatePickerListener
{
    void onDateSelected( DateTime dateSelected );
}