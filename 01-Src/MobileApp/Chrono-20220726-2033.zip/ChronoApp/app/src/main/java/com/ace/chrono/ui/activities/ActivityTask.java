package com.ace.chrono.ui.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsRoomDatabase;
import com.ace.chrono.data.entities.TimeSheetEntry;
import com.ace.chrono.databinding.LayoutActivityTaskBinding;
import com.ace.chrono.ui.adapters.AdapterFragmentTimeSheetCheckInItem;
import com.ace.chrono.ui.fragments.FragmentClockInAndOut;
import com.ace.chrono.ui.fragments.FragmentCreateSchedule;
import com.ace.chrono.ui.fragments.FragmentMembers;
import com.ace.chrono.ui.fragments.FragmentProfile;
import com.ace.chrono.util.UtilAppBottomNavHelper;
import com.google.android.material.navigation.NavigationView;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ActivityTask extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityTaskBinding _binding;
    private ActivityTaskViewModel _viewModel;
    private ActionBarDrawerToggle _toggle;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        _binding = LayoutActivityTaskBinding.inflate( getLayoutInflater() );
        _viewModel = new ViewModelProvider( this ).get( ActivityTaskViewModel.class );

        setContentView( _binding.getRoot() );
        setSupportActionBar( _binding.activityDashboardToolbar );

        initActionBar();
        initSideNavigationController();
        UtilAppBottomNavHelper.init( _binding.activityDashboardBottomNavView.appBottomNavigation,
                R.id.menu_activity_task );
        dumpData();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
    }

    @Override
    protected void onStart()
    {
        super.onStart();


        _binding.startClockingInBtn.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick( View view )
            {
                FragmentClockInAndOut fragment = new FragmentClockInAndOut();
                String fragmentTag = fragment.getClass().getSimpleName();

                fragmentTransaction( fragment, fragmentTag );
            }
        } );
        _viewModel.getTimeSheetEntries().subscribeOn( Schedulers.io() ).subscribe(
                new SingleObserver< List< TimeSheetEntry > >()
                {
                    @Override
                    public void onSubscribe( Disposable d )
                    {
                    }

                    @Override
                    public void onSuccess( List< TimeSheetEntry > timeSheetEntries )
                    {
                        AdapterFragmentTimeSheetCheckInItem adap =
                                new AdapterFragmentTimeSheetCheckInItem( timeSheetEntries,
                                        getApplicationContext() );

                        _binding.recyclerView.setAdapter( adap );
                        _binding.recyclerView.setLayoutManager(
                                new LinearLayoutManager( getApplicationContext() ) );
                    }

                    @Override
                    public void onError( Throwable e )
                    {

                    }
                } );

    }

    @SuppressLint( "NonConstantResourceId" )
    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item )
    {
        DrawerLayout drawerLayout = _binding.activityDashboardDrawerLayout;

        switch ( item.getItemId() )
        {
            case R.id.menu_dashboard_profile:
            {
                drawerLayout.closeDrawer( GravityCompat.START );
                FragmentProfile fragment = new FragmentProfile();
                String fragmentTag = fragment.getClass().getSimpleName();

                fragmentTransaction( fragment, fragmentTag );
                break;
            }
            case R.id.menu_dashboard_members:
            {
                drawerLayout.closeDrawer( GravityCompat.START );
                FragmentMembers fragment = new FragmentMembers();
                String fragmentTag = fragment.getClass().getSimpleName();

                fragmentTransaction( fragment, fragmentTag );
                break;
            }
            case R.id.menu_dashboard_timesheet:
            {
                drawerLayout.closeDrawer( GravityCompat.START );
                startActivity( new Intent( this, ActivityTImeSheet.class ) );
                break;
            }
            case R.id.menu_dashboard_schedule:
            {
                drawerLayout.closeDrawer( GravityCompat.START );
                FragmentCreateSchedule fragment = new FragmentCreateSchedule();
                String fragmentTag = fragment.getClass().getSimpleName();

                fragmentTransaction( fragment, fragmentTag );

                break;
            }
        }

        //Toggle needs navigation menu item so its important
        _toggle.onOptionsItemSelected( item );

        return super.onOptionsItemSelected( item );
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        getSupportActionBar().setTitle( getString( R.string.app_name ) );
    }


    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private void initBottomNavigationController()
    {
        NavController navController = Navigation.findNavController( this,
                _binding.activityDashboardSideFragmentHostContainer.getId() );
        AppBarConfiguration appBarConfiguration =
                new AppBarConfiguration.Builder( navController.getGraph() ).build();
        NavigationUI.setupWithNavController(
                _binding.activityDashboardToolbar, navController, appBarConfiguration );
    }

    private void initSideNavigationController()
    {
        DrawerLayout drawerLayout = _binding.activityDashboardDrawerLayout;

        _toggle = new ActionBarDrawerToggle( this, drawerLayout,
                R.string.nav_open, R.string.nav_close );

        drawerLayout.addDrawerListener( _toggle );
        _toggle.syncState();

        NavigationView navView = _binding.activityDashboardSideNavView;

        navView.setNavigationItemSelectedListener( this::onOptionsItemSelected );
    }

    private void initActionBar()
    {
        ActionBar actionBar = getSupportActionBar();

        assert actionBar != null;

        actionBar.setDisplayShowHomeEnabled( true );
        actionBar.setDisplayHomeAsUpEnabled( true );
        actionBar.setTitle( getString( R.string.app_name ) );
    }

    private void fragmentTransaction( Fragment f, String tag )
    {
        Fragment fragment = f;
        String fragmentTag = tag;

        getSupportFragmentManager()
                .beginTransaction()
                .addToBackStack( fragment.getClass().getSimpleName() )
                .setReorderingAllowed( true )
                .replace( _binding.activityDashboardSideFragmentHostContainer.getId(),
                        fragment,
                        fragmentTag
                )
                .commit();
    }

    private void dumpData()
    {
        for ( int i = 0; i <= 30; i++ )
        {
            TimeSheetEntry entry = new TimeSheetEntry();

            entry._dataStatus = ConstantsRoomDatabase.STATUS_CREATED;
            entry._projectName = " Member " + i;

            _viewModel.addTimeEntryToRoomDatabase( entry );
        }
    }
    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}