package com.ace.chrono.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.ace.chrono.databinding.LayoutActivityLoginBinding;
import com.ace.chrono.ui.fragments.FragmentForgotPassword;

public class ActivityLogin extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityLoginBinding _binding;

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutActivityLoginBinding.inflate( getLayoutInflater() );

        setContentView( _binding.getRoot() );
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        _binding.activityLoginSignupTv.setOnClickListener( view ->
        {
            startActivity( new Intent( ActivityLogin.this, ActivitySignUp.class ) );
        } );

        _binding.activityLoginForgotLoginBtn.setOnClickListener( view ->
        {
            FragmentForgotPassword fragment = new FragmentForgotPassword();
            String fragmentTag = fragment.getClass().getSimpleName();

            getSupportFragmentManager()
                    .beginTransaction()
                    .addToBackStack( fragment.getClass().getSimpleName() )
                    .setReorderingAllowed( true )
                    .replace( _binding.fragmentContainer.getId(), fragment, fragmentTag )
                    .commit();
        } );

        _binding.activityLoginPerformLoginBtn.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick( View view )
            {
                startActivity( new Intent( ActivityLogin.this, ActivityTask.class ) );
                finish();
            }
        } );
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}