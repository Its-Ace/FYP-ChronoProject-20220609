package com.ace.chrono.ui.fragments;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.ace.chrono.AppRepository;
import com.ace.chrono.data.entities.Project;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FragmentAssignTaskViewModel extends ViewModel
{
    // ==================================
    // Members
    // ==================================

    private final AppRepository _appRepository;

    public MutableLiveData< Boolean > isStateChanged = new MutableLiveData<>( true );
    private List< Project > _allProjects;
    private String _taskTitle;
    private String _taskProjectName;
    private String _taskDescription;
    private String _taskPriority;
    private String _taskFromDate;
    private String _taskToDate;

    // ==================================
    // Constructors
    // ==================================

    public FragmentAssignTaskViewModel()
    {
        _appRepository = AppRepository.INSTANCE();

        _appRepository.getProjectsLiveDataOnce().subscribeOn( Schedulers.io() ).subscribe(
                new SingleObserver< List< Project > >()
                {
                    @Override
                    public void onSubscribe( Disposable d )
                    {

                    }

                    @Override
                    public void onSuccess( List< Project > projects )
                    {
                        _allProjects = projects;
                    }

                    @Override
                    public void onError( Throwable e )
                    {

                    }
                } );
    }

    public LiveData< List< String > > getAllProjectsNames()
    {
        MutableLiveData< List< String > > liveProjectNames = new MediatorLiveData<>();

        List< String > projectNames = new ArrayList<>();

        for ( Project p : _allProjects )
        {
            projectNames.add( p._name );
        }

        liveProjectNames.postValue( projectNames );

        return liveProjectNames;
    }

    public String getTaskTitle()
    {
        return _taskTitle;
    }

    public void setTaskTitle( String _taskTitle )
    {
        this._taskTitle = _taskTitle;
    }

    public String getTaskProjectName()
    {
        return _taskProjectName;
    }

    public void setTaskProjectName( String _taskProjectName )
    {
        this._taskProjectName = _taskProjectName;
    }

    public String getTaskDescription()
    {
        return _taskDescription;
    }

    public void setTaskDescription( String _taskDescription )
    {
        this._taskDescription = _taskDescription;
    }

    public String getTaskPriority()
    {
        return _taskPriority;
    }

    public void setTaskPriority( String _taskPriority )
    {
        this._taskPriority = _taskPriority;
    }

    public String getTaskFromDate()
    {
        return _taskFromDate;
    }

    public void setTaskFromDate( String _taskFromDate )
    {
        this._taskFromDate = _taskFromDate;
    }

    public String getTaskToDate()
    {
        return _taskToDate;
    }

    public void setTaskToDate( String _taskToDate )
    {
        this._taskToDate = _taskToDate;
    }

    public Long getProjectIdByName( String projectName )
    {
        if ( projectName == null || projectName.isEmpty() )
        {
            return null;
        }
        else
        {
            for ( Project p : _allProjects )
            {
                if ( p._name.equals( projectName ) )
                {
                    return p._id;
                }
            }
        }

        throw new IllegalStateException( "Unhandled scenario" );
    }

}