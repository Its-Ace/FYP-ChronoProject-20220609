package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentTaskActionViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}