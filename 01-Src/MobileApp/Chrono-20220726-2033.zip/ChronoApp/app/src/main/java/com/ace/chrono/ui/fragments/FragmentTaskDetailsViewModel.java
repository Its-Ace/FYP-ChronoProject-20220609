package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentTaskDetailsViewModel extends ViewModel
{

    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public FragmentTaskDetailsViewModel()
    {
    }

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}