package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ace.chrono.R;

public class FragmentCheckIn extends Fragment
{

    private FragmentCheckInViewModel mViewModel;

    public static FragmentCheckIn newInstance()
    {
        return new FragmentCheckIn();
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        return inflater.inflate( R.layout.layout_fragment_check_in, container, false );
    }

    @Override
    public void onActivityCreated( @Nullable Bundle savedInstanceState )
    {
        super.onActivityCreated( savedInstanceState );
        mViewModel = new ViewModelProvider( this ).get( FragmentCheckInViewModel.class );
        // TODO: Use the ViewModel
    }

}