package com.ace.chrono.ui.activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.widget.TextView;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsActivityIntro;
import com.ace.chrono.data.preferences.PreferenceManagerAppLunch;
import com.ace.chrono.databinding.LayoutActivityHomeMemberBinding;
import com.ace.chrono.databinding.LayoutActivityHomeMemberBinding;
import com.ace.chrono.databinding.LayoutActivityIntroBinding;
import com.ace.chrono.ui.adapters.AdapterActivityIntroViewPagerItem;

public class ActivityHomeMember extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityHomeMemberBinding _binding;
    private ActivityHomeViewModel _viewModel;

    ///////////////////////////////////////////
    // Listeners
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    protected void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutActivityHomeMemberBinding.inflate( getLayoutInflater() );
    }

    @Override
    protected void onStart()
    {
        super.onStart();

    }

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}