package com.ace.chrono.util;

import android.annotation.SuppressLint;
import android.util.Log;

import com.ace.chrono.constants.ConstantsUtilDateTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class UtilDateTime
{
    private static final String TAG = "UtilDateTime";

    public static String CURRENT_DATE_TIME_AS_STRING()
    {
        Date d = Calendar.getInstance().getTime();
        return ConstantsUtilDateTime.DATE_TIME_FORMAT.format( d );
    }

    public static String CURRENT_DATE_AS_STRING()
    {
        Date d = Calendar.getInstance().getTime();
        return ConstantsUtilDateTime.DATE_FORMAT.format( d );
    }

    public static String EXTRACT_DATETIME_ONLY_AS_STRING( Date d )
    {
        return ConstantsUtilDateTime.DATE_TIME_FORMAT.format( d );
    }

    public static String EXTRACT_DATE_TIME_ON_NEW_LINE_ONLY_AS_STRING( Date d )
    {
        return ConstantsUtilDateTime.DATE_TIME_NEW_LINE_FORMAT.format( d );
    }


    public static String EXTRACT_TIME_ONLY_AS_STRING( Date d )
    {
        return ConstantsUtilDateTime.TIME_FORMAT.format( d );
    }

    public static String EXTRACT_TIME_WITH_H_M_S_AS_STRING( Date d )
    {
        return ConstantsUtilDateTime.TIME_FORMAT_H_M_S.format( d );
    }

    public static String EXTRACT_TIME_WITH_M_S_AS_STRING( Date d )
    {
        return ConstantsUtilDateTime.TIME_FORMAT_M_S.format( d );
    }

    public static String EXTRACT_TIME_WITH_AM_PM_STRING( Date d )
    {
        return ConstantsUtilDateTime.TIME_FORMAT_AM_PM.format( d );
    }

    public static String EXTRACT_DATE_ONLY_AS_STRING( Date d )
    {
        return ConstantsUtilDateTime.DATE_FORMAT.format( d );
    }

    public static Date STRING_TO_DATE( String s )
    {
        Date d = null;

        try
        {
            d = ConstantsUtilDateTime.DATE_FORMAT.parse( s );
        }
        catch ( ParseException e )
        {
            e.printStackTrace();
        }

        return d;
    }

    public static Date STRING_TO_DATE_AND_TIME( String s )
    {
        Date d = null;

        try
        {
            d = ConstantsUtilDateTime.DATE_TIME_FORMAT.parse( s );
        }
        catch ( ParseException e )
        {
            e.printStackTrace();
        }

        return d;
    }

    public static Calendar STRING_TO_CALENDAR( String s )
    {
        Calendar c = Calendar.getInstance();

        c.setTime( UtilDateTime.STRING_TO_DATE( s ) );

        return c;
    }

    public static boolean IS_TODAY( String d )
    {
        // Create date from input value
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( d );

        // Get today's date
        Calendar todayCalendar = Calendar.getInstance();

        int todayDay = todayCalendar.get( Calendar.DAY_OF_MONTH );
        int todayMonth = todayCalendar.get( Calendar.MONTH );
        int todayYear = todayCalendar.get( Calendar.YEAR );

        int inputDay = inputCalendar.get( Calendar.DAY_OF_MONTH );
        int inputMonth = inputCalendar.get( Calendar.MONTH );
        int inputYear = inputCalendar.get( Calendar.YEAR );

        // Input date equals today's date
        return ( todayDay == inputDay && todayMonth == inputMonth && todayYear == inputYear );
    }

    //Below methode is written By Yaseen
    public static boolean IS_DAY_EQUALS_CALENDARS_DAY( String d, Calendar givenCalendar )
    {
        // Create date from input value
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( d );

        int calendarDay = givenCalendar.get( Calendar.DAY_OF_MONTH );
        int calendarMonth = givenCalendar.get( Calendar.MONTH );
        int calendarYear = givenCalendar.get( Calendar.YEAR );

        int inputDay = inputCalendar.get( Calendar.DAY_OF_MONTH );
        int inputMonth = inputCalendar.get( Calendar.MONTH );
        int inputYear = inputCalendar.get( Calendar.YEAR );

        // Input date equals today's date
        return ( calendarDay == inputDay && calendarMonth == inputMonth && calendarYear == inputYear );
    }

    public static boolean IS_DATE_IN_THE_CURRENT_WEEK_OF_YEAR( String d )
    {
        // Create date from input value
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( d );

        // Get today's date
        Calendar todayCalendar = Calendar.getInstance();

        // if today is Tuesday, return TRUE for last Mon and Tue
        // if today is Friday, return TRUE for last Mon, Tue, Wed, Thu and Fri
        // if today is Sunday, return TRUE for last Mon, Tue, Wed, Thu, Fri, Sat and Sun
        int todayWeek = todayCalendar.get( Calendar.WEEK_OF_YEAR );
        int todayYear = todayCalendar.get( Calendar.YEAR );

        int targetWeek = inputCalendar.get( Calendar.WEEK_OF_YEAR );
        int targetYear = inputCalendar.get( Calendar.YEAR );

        return ( ( todayWeek == targetWeek ) && ( todayYear == targetYear ) );
    }

    //Below methode is written By Yaseen
    public static boolean IS_DATE_IN_THE_CALENDAR_WEEK_OF_YEAR( String d, Calendar givenCalendar )
    {
        // Create date from input value
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( d );

        // if today is Tuesday, return TRUE for last Mon and Tue
        // if today is Friday, return TRUE for last Mon, Tue, Wed, Thu and Fri
        // if today is Sunday, return TRUE for last Mon, Tue, Wed, Thu, Fri, Sat and Sun
        int calendarWeek = givenCalendar.get( Calendar.WEEK_OF_YEAR );
        int calendarYear = givenCalendar.get( Calendar.YEAR );

        int targetWeek = inputCalendar.get( Calendar.WEEK_OF_YEAR );
        int targetYear = inputCalendar.get( Calendar.YEAR );

        return ( ( calendarWeek == targetWeek ) && ( calendarYear == targetYear ) );
    }

    //Below methode is written By Yaseen
    public static boolean IS_DATE_IN_THE_CURRENT_MONTH_OF_YEAR( String d )
    {
        // Create date from input value
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( d );

        // Get today's date
        Calendar todayCalendar = Calendar.getInstance();

        int todayMonth = todayCalendar.get( Calendar.MONTH );
        int todayYear = todayCalendar.get( Calendar.YEAR );

        int targetMonth = inputCalendar.get( Calendar.MONTH );
        int targetYear = inputCalendar.get( Calendar.YEAR );

        // call setHours to take the time out of the comparison
        return ( ( todayMonth == targetMonth ) && ( todayYear == targetYear ) );
    }

    //Below methode is written By Yaseen
    public static boolean IS_DATE_IN_THE_CALENDAR_MONTH_OF_YEAR( String d, Calendar givenCalendar )
    {
        // Create date from input value
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( d );

        int calendarMonth = givenCalendar.get( Calendar.MONTH );
        int calendarYear = givenCalendar.get( Calendar.YEAR );

        int targetMonth = inputCalendar.get( Calendar.MONTH );
        int targetYear = inputCalendar.get( Calendar.YEAR );

        // call setHours to take the time out of the comparison
        return ( ( calendarMonth == targetMonth ) && ( calendarYear == targetYear ) );
    }

    public static String SPECIFIC_DATE_WITH_CURRENT_TIME_AS_STRING( String date )
    {
        // Get today's date
        Calendar todayCalendar = Calendar.getInstance();

        // Get specified date calendar
        Calendar inputCalendar = UtilDateTime.STRING_TO_CALENDAR( date );

        inputCalendar.set( Calendar.HOUR_OF_DAY, todayCalendar.get( Calendar.HOUR_OF_DAY ) );
        inputCalendar.set( Calendar.MINUTE, todayCalendar.get( Calendar.MINUTE ) );
        inputCalendar.set( Calendar.SECOND, todayCalendar.get( Calendar.SECOND ) );

        return UtilDateTime.EXTRACT_DATETIME_ONLY_AS_STRING( inputCalendar.getTime() );
    }

    public static int GET_NO_DAYS_IN_MONTH( int month )
    {
        Calendar calendar = Calendar.getInstance();

        calendar.set( Calendar.MONTH, month );

        return calendar.getActualMaximum( Calendar.DAY_OF_MONTH );
    }

    public static Date TIME_IN_MILLS_TO_DATE( long timeInMills )
    {
        return new Date( timeInMills );
    }

    @SuppressLint( "DefaultLocale" )
    public static String DURATION_TO_TIME_AS_STRING( int duration )
    {
        int sec = duration;
        Date d = new Date( sec * 1000L );
        @SuppressLint( "SimpleDateFormat" )
        SimpleDateFormat df = new SimpleDateFormat( "HH:mm:ss" ); // HH for 0-23
        df.setTimeZone( TimeZone.getTimeZone( "GMT" ) );
        return df.format( d );
    }

    /**
     * Extract the durations as the FORMAT (mm:ss) or (HH:mm:ss)
     * @param end end Date of something
     * @param start start date of something
     * @return String of Time 00:00 or 00:00:00
     */
    public static String EXTRACT_DURATION_FROM( Date end, Date start )
    {
        long diff = end.getTime() - start.getTime();

        String time = String.format( "[%s]:[%s]:[%s]",
                Long.toString( TimeUnit.MILLISECONDS.toHours( diff ) ),
                TimeUnit.MILLISECONDS.toMinutes( diff ),
                TimeUnit.MILLISECONDS.toSeconds( diff ) );

        int hours = ( int ) TimeUnit.MILLISECONDS.toHours( diff );
        int minutes = ( int ) TimeUnit.MILLISECONDS.toMinutes( diff );
        int seconds = ( int ) TimeUnit.MILLISECONDS.toSeconds( diff );

        Calendar calendar = Calendar.getInstance();
        calendar.set( Calendar.HOUR, hours );
        calendar.set( Calendar.MINUTE, minutes );
        calendar.set( Calendar.SECOND, seconds );

        Log.d( TAG, "EXTRACT_DURATION_FROM: " + time );

        if ( hours > 0 )
        {
            //Date time with hours
            return UtilDateTime.EXTRACT_TIME_WITH_H_M_S_AS_STRING( calendar.getTime() );
        }
        else
        {
            //Date time with minutes
            return UtilDateTime.EXTRACT_TIME_WITH_M_S_AS_STRING( calendar.getTime() );
        }
    }

    public static boolean IS_DATE_SAME( String s, Calendar c )
    {
        Calendar a = UtilDateTime.STRING_TO_CALENDAR( s );

        return ( ( a.get( Calendar.DAY_OF_MONTH ) == c.get( Calendar.DAY_OF_MONTH ) )
                && ( a.get( Calendar.MONTH ) == c.get( Calendar.MONTH ) )
                && ( a.get( Calendar.YEAR ) == c.get( Calendar.YEAR ) ) );
    }

    public static boolean IS_DATE_SAME( Calendar s, Calendar c )
    {
        Calendar a = s;

        return ( ( a.get( Calendar.DAY_OF_MONTH ) == c.get( Calendar.DAY_OF_MONTH ) )
                && ( a.get( Calendar.MONTH ) == c.get( Calendar.MONTH ) )
                && ( a.get( Calendar.YEAR ) == c.get( Calendar.YEAR ) ) );
    }

    public static boolean IS_DATE_BETWEEN_TWO_DATES(Date toCheck, Date fromDate,
                                                    Date toDate )
    {
        Date min = fromDate;
        Date max = toDate;

        Date d = toCheck;

        return d.compareTo(min) >= 0 && d.compareTo(max) <= 0;
    }
}
