package com.ace.chrono.ui.activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.ace.chrono.databinding.LayoutActivityProfileBinding;

public class ActivityProfile extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityProfileBinding _binding;
    private ActivityProfileViewModel _viewModel;

    ///////////////////////////////////////////
    // Listeners
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    protected void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutActivityProfileBinding.inflate( getLayoutInflater() );

        setContentView( _binding.getRoot() );
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        _binding.activityProfileToolbar.setNavigationOnClickListener( v -> onBackPressed() );
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}