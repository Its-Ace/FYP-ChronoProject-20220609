package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentClockInAndOutViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}