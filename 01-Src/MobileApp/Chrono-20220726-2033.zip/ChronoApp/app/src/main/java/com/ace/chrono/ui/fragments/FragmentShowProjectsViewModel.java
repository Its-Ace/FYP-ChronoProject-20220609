package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentShowProjectsViewModel extends ViewModel
{

}