package com.ace.chrono.ui.activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ace.chrono.R;
import com.ace.chrono.databinding.LayoutActivityTaskAdminBinding;
import com.ace.chrono.util.UtilAppBottomNavHelper;
import com.ace.horizontaldatepicker.HorizontalPicker;

public class ActivityTaskAdmin extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityTaskAdminBinding _binding;

    ///////////////////////////////////////////
    // Listeners
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public ActivityTaskAdmin()
    {
    }


    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


    @Override
    protected void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutActivityTaskAdminBinding.inflate( getLayoutInflater() );

        setContentView( _binding.getRoot() );

        UtilAppBottomNavHelper.init( _binding.activityTaskAdminBottomNavigation.appBottomNavigation,
                R.id.menu_activity_task );

        HorizontalPicker d = _binding.horizontalDatePicker;

        HorizontalPicker.initDatePicker(d, R.color.primaryColor, R.color.primaryColor );
    }

    @Override
    protected void onStart()
    {
        super.onStart();
    }


    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\



    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}