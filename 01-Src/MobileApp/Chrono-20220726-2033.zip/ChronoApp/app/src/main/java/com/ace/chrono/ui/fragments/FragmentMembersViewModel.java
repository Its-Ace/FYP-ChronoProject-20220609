package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

import com.ace.chrono.AppRepository;
import com.ace.chrono.data.entities.Member;

import java.util.List;

import io.reactivex.Single;

public class FragmentMembersViewModel extends ViewModel
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private AppRepository _appRepository;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public FragmentMembersViewModel()
    {
        _appRepository = AppRepository.INSTANCE();
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public void addMembersToRoomDatabase( Member entry )
    {
        _appRepository.insetMemberEntry( entry );
    }

    public Single< List< Member > > getMembersLiveData()
    {
        return _appRepository.getMembersLiveDataOnce();
    }

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

}