package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentCreateGroupViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}