package com.ace.chrono.ui.fragments;

import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsActivityIntro;
import com.ace.chrono.databinding.LayoutFragmentTaskPoliciesBinding;
import com.ace.chrono.ui.adapters.AdapterFragmentPoliciesPagerItem;

public class FragmentTaskPolicies extends Fragment
{

    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutFragmentTaskPoliciesBinding _binding;
    private FragmentPoliciesViewModel _viewModel;
    private final ViewPager2.OnPageChangeCallback pagerChangeListener = new ViewPager2.OnPageChangeCallback()
    {
        @Override
        public void onPageScrolled( int position, float positionOffset, int positionOffsetPixels )
        {
            super.onPageScrolled( position, positionOffset, positionOffsetPixels );

            addSliderDots( position );
        }
    };

    ///////////////////////////////////////////
    // Listeners
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutFragmentTaskPoliciesBinding.inflate( getLayoutInflater() );
        _viewModel = new ViewModelProvider( this ).get( FragmentPoliciesViewModel.class );
    }

    @Nullable
    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        return _binding.getRoot();
    }

    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );

        initIntroPagerAdapter();
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private void initIntroPagerAdapter()
    {
        ViewPager2 viewPager2 = _binding.fragmentPoliciesViewPager2;

        CompositePageTransformer pageTransformer = new CompositePageTransformer();

        pageTransformer.addTransformer( new MarginPageTransformer( 40 ) );
        pageTransformer.addTransformer( ( page, position ) ->
        {
            float r = 1 - Math.abs( position );
            page.setScaleY( 0.95f + r * 0.15f );
        } );

        AdapterFragmentPoliciesPagerItem _introPagerAdapter =
                new AdapterFragmentPoliciesPagerItem();

        viewPager2.setAdapter( _introPagerAdapter );
        viewPager2.registerOnPageChangeCallback( pagerChangeListener );
        viewPager2.setClipToPadding( false );
        viewPager2.setClipChildren( false );
        viewPager2.setOffscreenPageLimit( 3 );
        viewPager2.getChildAt( 0 ).setOverScrollMode( RecyclerView.OVER_SCROLL_NEVER );
        viewPager2.setPageTransformer( pageTransformer );
    }

    private void addSliderDots( int position )
    {
        TextView[] _decorationDots =
                new TextView[ ConstantsActivityIntro.activity_intro_layouts_ids.length ];

        int[] colorsActive = getResources().getIntArray( R.array.array_dot_active );
        int[] colorsInactive = getResources().getIntArray( R.array.array_dot_inactive );

        _binding.fragmentPoliciesDotsLayout.removeAllViews();

        for ( int i = 0; i < _decorationDots.length; i++ )
        {
            _decorationDots[ i ] = new TextView( getContext() );
            _decorationDots[ i ].setText( Html.fromHtml( "&#8226;" ) );
            _decorationDots[ i ].setTextSize( 35 );
            _decorationDots[ i ].setTextColor( colorsInactive[ position ] );
            _binding.fragmentPoliciesDotsLayout.addView( _decorationDots[ i ] );
        }

        if ( _decorationDots.length > 0 )
        {
            _decorationDots[ position ].setTextColor( colorsActive[ position ] );
        }
    }

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}