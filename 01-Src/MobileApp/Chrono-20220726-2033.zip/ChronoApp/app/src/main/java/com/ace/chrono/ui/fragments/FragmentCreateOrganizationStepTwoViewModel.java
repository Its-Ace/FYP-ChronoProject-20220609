package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentCreateOrganizationStepTwoViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}