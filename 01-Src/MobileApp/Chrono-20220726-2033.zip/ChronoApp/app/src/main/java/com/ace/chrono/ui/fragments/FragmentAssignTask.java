package com.ace.chrono.ui.fragments;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsApp;
import com.ace.chrono.constants.ConstantsProject;
import com.ace.chrono.databinding.LayoutFragmentAssignTaskBinding;
import com.ace.chrono.util.UtilDateTime;

import java.util.Calendar;
import java.util.Date;

import io.github.mthli.knife.RichTextEditor;


public class FragmentAssignTask extends Fragment
{
    // ==================================
    // Members
    // ==================================

    private FragmentAssignTaskViewModel _viewModel;
    private LayoutFragmentAssignTaskBinding _binding;

    // ==================================
    // Constructors
    // ==================================


    // ==================================
    // Overrides
    // ==================================

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( FragmentAssignTaskViewModel.class );
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        _binding = LayoutFragmentAssignTaskBinding.inflate( getLayoutInflater(), container, false );

        return _binding.getRoot();
    }

    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );

        RichTextEditor text = _binding.descriptionRichTextEditor;
        text.init();

        FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();

        requireActivity().getIntent().setAction( null );

        initPrioritySpinner();

        _viewModel.isStateChanged.observe( getViewLifecycleOwner(), aBoolean ->
        {
            int priorityIndex =
                    ConstantsProject.TASK_PRIORITIES.indexOf( _viewModel.getTaskPriority() );

            _binding.taskTitleInputLayout.getEditText().setText( _viewModel.getTaskTitle() );
            _binding.taskProjectsSpinner.getEditText().setText(
                    _viewModel.getTaskProjectName() );
            _binding.descriptionRichTextEditor.getCustomEditText().setText(
                    _viewModel.getTaskDescription() );
            _binding.taskPrioritySpinner.setSelection( priorityIndex );
            _binding.fromDateTextView.setText( _viewModel.getTaskToDate() );
            _binding.toDateTextView.setText( _viewModel.getTaskFromDate() );
        } );

        _binding.fragmentAssignTaskToolbar.setNavigationOnClickListener(
                v -> requireActivity().getSupportFragmentManager().popBackStackImmediate() );


        _viewModel.getAllProjectsNames().observe( getViewLifecycleOwner(), projects ->
        {
            if ( projects.size() > 0 )
            {
                ArrayAdapter< String > adapter = new ArrayAdapter<>( getContext(),
                        android.R.layout.simple_dropdown_item_1line, projects );
                AutoCompleteTextView textView =
                        ( AutoCompleteTextView ) _binding.taskProjectsSpinner.getEditText();
                textView.setAdapter( adapter );
            }
            else
            {
                fragmentManager.popBackStackImmediate();
                AlertDialog builder = new AlertDialog.Builder( getContext() )
                        .setTitle( "No projects found!" )
                        .setMessage( "Please add projects in order to create tasks." )
                        .setPositiveButton( ConstantsApp.ALERT_DIALOG_POSITIVE_BUTTON_OK, null )
                        .show();
            }
        } );

        _binding.createTaskButton.setOnClickListener( v -> createTask() );

        String currentDate =
                UtilDateTime.EXTRACT_DATE_ONLY_AS_STRING( Calendar.getInstance().getTime() );

        _binding.fromDateTextView.setText( currentDate );
        _viewModel.setTaskFromDate( currentDate );

        _binding.fromDateTextView.setOnClickListener( v ->
        {
            DatePickerDialog datePickerDialog = new DatePickerDialog( getContext() );

            datePickerDialog.setOnDateSetListener( ( view1, year, month, dayOfMonth ) ->
            {
                Calendar calendar = Calendar.getInstance();

                calendar.set( Calendar.YEAR, year );
                calendar.set( Calendar.MONTH, month );
                calendar.set( Calendar.DAY_OF_MONTH, dayOfMonth );

                String s = UtilDateTime.EXTRACT_DATE_ONLY_AS_STRING( calendar.getTime() );
                _binding.fromDateTextView.setText( s );
                _viewModel.setTaskFromDate( s );
            } );

            datePickerDialog.show();
        } );

        _binding.toDateTextView.setText( currentDate );
        _viewModel.setTaskToDate( currentDate );

        _binding.toDateTextView.setOnClickListener( v ->
        {
            DatePickerDialog datePickerDialog = new DatePickerDialog( getContext() );

            datePickerDialog.setOnDateSetListener( ( view1, year, month, dayOfMonth ) ->
            {
                Calendar calendar = Calendar.getInstance();

                calendar.set( Calendar.YEAR, year );
                calendar.set( Calendar.MONTH, month );
                calendar.set( Calendar.DAY_OF_MONTH, dayOfMonth );

                String s = UtilDateTime.EXTRACT_DATE_ONLY_AS_STRING( calendar.getTime() );
                _binding.toDateTextView.setText( s );
                _viewModel.setTaskToDate( s );
            } );

            datePickerDialog.show();
        } );

        _binding.taskTitleInputLayout.getEditText().addTextChangedListener( new TextWatcher()
        {
            @Override
            public void beforeTextChanged( CharSequence s, int start, int count, int after )
            {

            }

            @Override
            public void onTextChanged( CharSequence s, int start, int before, int count )
            {
                _viewModel.setTaskTitle( s.toString() );
            }

            @Override
            public void afterTextChanged( Editable s )
            {

            }
        } );

        _binding.taskProjectsSpinner.getEditText().addTextChangedListener( new TextWatcher()
        {
            @Override
            public void beforeTextChanged( CharSequence s, int start, int count, int after )
            {

            }

            @Override
            public void onTextChanged( CharSequence s, int start, int before, int count )
            {
                if ( s != null && s.length() > 0 )
                {
                    _viewModel.setTaskProjectName( s.toString() );
                }
            }

            @Override
            public void afterTextChanged( Editable s )
            {

            }
        } );

        _binding.descriptionRichTextEditor.getCustomEditText().addTextChangedListener(
                new TextWatcher()
                {
                    @Override
                    public void beforeTextChanged( CharSequence s, int start, int count, int after )
                    {

                    }

                    @Override
                    public void onTextChanged( CharSequence s, int start, int before, int count )
                    {
                        _viewModel.setTaskDescription( s.toString() );
                    }

                    @Override
                    public void afterTextChanged( Editable s )
                    {

                    }
                } );

        _binding.taskPrioritySpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener()
                {
                    @Override
                    public void onItemSelected( AdapterView< ? > parent, View view, int position,
                                                long id )
                    {
                        String priority = parent.getSelectedItem().toString();
                        _viewModel.setTaskPriority( priority );
                    }

                    @Override
                    public void onNothingSelected( AdapterView< ? > parent )
                    {

                    }
                } );
    }

    @Override
    public void onResume()
    {
        super.onResume();
    }

    // ==================================
    // Methods
    // ==================================

    private void initPrioritySpinner()
    {
        Spinner spinner = _binding.taskPrioritySpinner;

        ArrayAdapter< String > arrayAdapter = new ArrayAdapter<>( getContext(),
                com.google.android.material.R.layout.support_simple_spinner_dropdown_item,
                ConstantsProject.TASK_PRIORITIES );
        arrayAdapter.setDropDownViewResource(
                com.google.android.material.R.layout.support_simple_spinner_dropdown_item );

        spinner.setAdapter( arrayAdapter );
    }

    private boolean createTask()
    {
        //Needs checks todo

        String description = _viewModel.getTaskDescription();
        String title = _viewModel.getTaskTitle();
        String projectSelected = _viewModel.getTaskProjectName();
        Long projectId = _viewModel.getProjectIdByName( projectSelected );
        String priority = _viewModel.getTaskPriority();
        Date fromDate = UtilDateTime.STRING_TO_DATE( _viewModel.getTaskFromDate() );
        Date toDate = UtilDateTime.STRING_TO_DATE( _viewModel.getTaskToDate() );

        new androidx.appcompat.app.AlertDialog.Builder( requireContext() )
                .setTitle( "Created" )
                .setCancelable( false )
                .setMessage( "Task has been created." )
                .setPositiveButton( R.string.dialog_button_ok,
                        ( dialog, which ) -> requireActivity().getSupportFragmentManager().popBackStackImmediate() )
                .show();
        return true;
    }

    private void gotoActivity( AppCompatActivity ctx, Class< ? > cls )
    {
        Intent newIntent = new Intent( ctx, cls );
        newIntent.addFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
        startActivity( newIntent );

        // finishAffinity();
    }

    // ==================================
    // END OF CLASS
    // ==================================
}