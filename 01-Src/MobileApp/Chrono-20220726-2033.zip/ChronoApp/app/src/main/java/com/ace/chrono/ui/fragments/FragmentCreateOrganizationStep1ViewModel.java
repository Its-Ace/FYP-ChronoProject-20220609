package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentCreateOrganizationStep1ViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}