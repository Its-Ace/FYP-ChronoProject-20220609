package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsRoomDatabase;
import com.ace.chrono.data.entities.Member;
import com.ace.chrono.data.entities.TimeSheetEntry;
import com.ace.chrono.databinding.LayoutFragmentAddMemberBinding;
import com.ace.chrono.ui.adapters.AdapterFragmentTimeSheetCheckInItem;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FragmentAddMember extends Fragment
{

    private FragmentAddMemberViewModel _viewModel;
    private LayoutFragmentAddMemberBinding _binding;

    public static FragmentAddMember newInstance()
    {
        return new FragmentAddMember();
    }


    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( FragmentAddMemberViewModel.class );
        _binding = LayoutFragmentAddMemberBinding.inflate( getLayoutInflater() );
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        return  _binding.getRoot();
    }

    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );



    }
}