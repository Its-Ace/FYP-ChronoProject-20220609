package com.ace.chrono.ui.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ace.chrono.databinding.LayoutActivityDashboardMemberBinding;

public class ActivityDashboardMember extends AppCompatActivity
{

    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityDashboardMemberBinding _binding;
    private ActivityDashboardMemberViewModel _viewModel;

    ///////////////////////////////////////////
    // Listeners
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}