package com.ace.chrono.ui.fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsFragmentNames;
import com.ace.chrono.constants.ConstantsRoomDatabase;
import com.ace.chrono.data.entities.Member;
import com.ace.chrono.data.entities.TimeSheetEntry;
import com.ace.chrono.databinding.LayoutFragmentMembersBinding;
import com.ace.chrono.ui.adapters.AdapterFragmentMemberItem;
import com.ace.chrono.ui.adapters.AdapterFragmentTimeSheetCheckInItem;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class FragmentMembers extends Fragment
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private FragmentMembersViewModel _viewModel;
    private LayoutFragmentMembersBinding _binding;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( FragmentMembersViewModel.class );
        _binding = LayoutFragmentMembersBinding.inflate( getLayoutInflater() );

        setHasOptionsMenu( true );
        initData();
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        return _binding.getRoot();
    }

    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );

        _binding.layoutFragmentAddMemberToolbar.setNavigationOnClickListener(
                v -> requireActivity().getSupportFragmentManager().popBackStackImmediate() );

        _viewModel.getMembersLiveData().subscribeOn( Schedulers.io() ).subscribe(
                new SingleObserver< List< Member > >()
                {
                    @Override
                    public void onSubscribe( Disposable d )
                    {
                    }

                    @Override
                    public void onSuccess( List< Member > members )
                    {
                        AdapterFragmentMemberItem adap =
                                new AdapterFragmentMemberItem( members,
                                        getContext() );

                        _binding.fragmentMemberRecyclerView.setAdapter( adap );
                        _binding.fragmentMemberRecyclerView.setLayoutManager(
                                new LinearLayoutManager( getContext() ) );
                    }

                    @Override
                    public void onError( Throwable e )
                    {

                    }
                } );
    }

    @Override
    public void onCreateOptionsMenu( @NonNull Menu menu, @NonNull MenuInflater inflater )
    {
        inflater.inflate(R.menu.fragment_add_member_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item )
    {
        switch (item.getItemId()) {
            case R.id.fragment_add_member_menu_add:
            {
                FragmentAddMember fragment = new FragmentAddMember();
                String fragmentTag = fragment.getClass().getSimpleName();

                getParentFragmentManager()
                        .beginTransaction()
                        .addToBackStack( fragment.getClass().getSimpleName() )
                        .setReorderingAllowed( true )
                        .replace( R.id.fragment_container,
                                fragment,
                                fragmentTag
                        )
                        .commit();
                break;
            }
            case R.id.fragment_add_member_menu_group:
            {
                break;
            }
            default:
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private void initData()
    {
        for ( int i = 0; i< 30; i++  )
        {
            Member member = new Member();

            member._memberName = "Person name " + i;
            member._memberDescription = "Last check in was 2 July, 20:00 " + i;
            member._dataStatus = ConstantsRoomDatabase.STATUS_CREATED;
        }
    }


    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

}