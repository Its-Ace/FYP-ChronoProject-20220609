package com.ace.chrono.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.R;
import com.ace.chrono.databinding.LayoutFragmentCreateTaskBinding;

public class FragmentCreateTask extends Fragment
{
    // ==================================
    // Members
    // ==================================

    private FragmentCreateTaskViewModel _viewModel;
    private LayoutFragmentCreateTaskBinding _binding;

    // ==================================
    // Constructors
    // ==================================

    public FragmentCreateTask()
    {
    }

    // ==================================
    // Overrides
    // ==================================

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( FragmentCreateTaskViewModel.class );
        _binding = LayoutFragmentCreateTaskBinding.inflate( getLayoutInflater() );

    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        //TODO : ( Check how attaching works - REF (container, ATTACH TO ROOT) ) -> Yaseen
        return _binding.getRoot();
    }


    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );

        _binding.createATaskTvBtn.setOnClickListener( v ->
        {
            FragmentAssignTask fragment = new FragmentAssignTask();
            String tag = fragment.getClass().getSimpleName();

            displayFragment( fragment, tag );
        } );
    }

    // ==================================
    // Methods
    // ==================================

    private void displayFragment( Fragment fragment, String tag )
    {
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .addToBackStack( tag )
                .setReorderingAllowed( true )
                //.addSharedElement(_binding.sizeToolbar, "menu_item_transition")
                .replace( R.id.fragment_container, fragment, tag )
                .commit();
    }

    // ==================================
    // END OF CLASS
    // ==================================
}