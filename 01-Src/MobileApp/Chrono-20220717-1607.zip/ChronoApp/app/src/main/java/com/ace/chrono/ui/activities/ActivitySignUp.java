package com.ace.chrono.ui.activities;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.R;
import com.ace.chrono.databinding.LayoutActivitySignupBinding;
import com.ace.chrono.ui.fragments.FragmentAddMember;
import com.ace.chrono.ui.fragments.FragmentCreateOrganizationStep1;
import com.ace.chrono.ui.fragments.FragmentJoinOrganization;

public class ActivitySignUp extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private ActivitySignUpViewModel _viewModel;
    private LayoutActivitySignupBinding _binding;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( ActivitySignUpViewModel.class );
        _binding = LayoutActivitySignupBinding.inflate( getLayoutInflater() );

        setContentView( _binding.getRoot() );
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        _binding.activitySignUpToolbar.setNavigationOnClickListener( view -> onBackPressed() );

        _binding.activitySignUpCreateAnOrganization.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick( View view )
            {
                FragmentCreateOrganizationStep1 fragment = new FragmentCreateOrganizationStep1();
                String fragmentTag = fragment.getClass().getSimpleName();

                getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack( fragment.getClass().getSimpleName() )
                        .setReorderingAllowed( true )
                        .replace( R.id.activity_signup_fragment_container,
                                fragment,
                                fragmentTag
                        )
                        .commit();
            }
        } );

        _binding.activitySignUpJoinAnOrganization.setOnClickListener( new View.OnClickListener()
        {
            @Override
            public void onClick( View view )
            {
                FragmentJoinOrganization fragment = new FragmentJoinOrganization();
                String fragmentTag = fragment.getClass().getSimpleName();

                getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack( fragment.getClass().getSimpleName() )
                        .setReorderingAllowed( true )
                        .replace( R.id.activity_signup_fragment_container,
                                fragment,
                                fragmentTag
                        )
                        .commit();
            }
        } );
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}