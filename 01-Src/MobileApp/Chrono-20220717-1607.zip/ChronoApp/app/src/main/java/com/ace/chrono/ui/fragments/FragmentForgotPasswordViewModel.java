package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

import com.ace.chrono.AppRepository;
import com.ace.chrono.databinding.LayoutActivityIntroBinding;

public class FragmentForgotPasswordViewModel extends ViewModel
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private AppRepository _appRepository;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public FragmentForgotPasswordViewModel()
    {
        _appRepository = AppRepository.INSTANCE();
    }

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

}
