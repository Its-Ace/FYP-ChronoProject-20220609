package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

import com.ace.chrono.AppRepository;
import com.ace.chrono.data.entities.Member;
import com.ace.chrono.data.entities.TimeSheetEntry;

import java.util.List;

import io.reactivex.Single;

public class FragmentAddMemberViewModel extends ViewModel
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private AppRepository _appRepository;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public FragmentAddMemberViewModel()
    {
        _appRepository = AppRepository.INSTANCE();
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    public void addMembersToRoomDatabase( Member entry )
    {
        _appRepository.insetMemberEntry( entry );
    }

    public Single< List< TimeSheetEntry > > getTimeSheetEntries()
    {
        return _appRepository.getTimeEntryLiveDataOnce();
    }

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}