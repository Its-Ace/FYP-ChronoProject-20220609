package com.ace.chrono.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.R;
import com.ace.chrono.databinding.LayoutFragmentShowProjectsBinding;

public class FragmentShowProjects extends Fragment
{
    // ==================================
    // Members
    // ==================================

    private FragmentShowProjectsViewModel _viewModel;
    private LayoutFragmentShowProjectsBinding _binding;

    // ==================================
    // Constructors
    // ==================================

    // ==================================
    // Overrides
    // ==================================

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( FragmentShowProjectsViewModel.class );
        _binding = LayoutFragmentShowProjectsBinding.inflate( getLayoutInflater() );
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        return _binding.getRoot();
    }

    @Override
    public void onStart()
    {
        super.onStart();

        _binding.projectAddBtn.setOnClickListener( v ->
        {
            
        } );
    }

    // ==================================
    // Members
    // ==================================

    private void displayFragment( Fragment fragment, String tag )
    {
        getActivity().getSupportFragmentManager()
                .beginTransaction()
                .addToBackStack( tag )
                .setReorderingAllowed( true )
                //.addSharedElement(_binding.sizeToolbar, "menu_item_transition")
                .replace( R.id.fragment_container, fragment, tag )
                .commit();
    }


    // ==================================
    // END OF CLASS
    // ==================================
}