package com.ace.chrono.util;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Global executor pools for the whole application.
 * <p>
 * Grouping tasks like this avoids the effects of task starvation (e.g. disk reads don't wait behind
 * webservice requests).
 */
public class UtilAppExecutors
{
    // For Singleton instantiation
    private static final Object LOCK = new Object();

    private static UtilAppExecutors sInstance;

    private final Executor diskIO;
    private final Executor mainThread;
    private final Executor networkIO;

    /**
     *
     * @param diskIO Single Thread Executor
     * @param networkIO Execute with thread pool size of Three
     * @param mainThread MainThread
     */
    private UtilAppExecutors(
            Executor diskIO,
            Executor networkIO,
            Executor mainThread
    )
    {
        this.diskIO = diskIO;
        this.networkIO = networkIO;
        this.mainThread = mainThread;
    }

    /**
     * Method to get an entry point to AppExecutors.
     */
    public static UtilAppExecutors getInstance()
    {
        if (sInstance == null)
        {
            synchronized (LOCK)
            {
                sInstance = new UtilAppExecutors(
                        Executors.newSingleThreadExecutor(),
                        Executors.newFixedThreadPool(3),
                        new MainThreadExecutor()
                );
            }
        }
        return sInstance;
    }

    /**
     * DiskIO is a Single Thread Executor (see above).
     * It ensures that our database transactions are done in order so we do not have
     * race conditions
     */
    public Executor diskIO() {
        return diskIO;
    }

    /**
     * The mainThread executor uses the "MainThreadExecutor" class which essentially will pause
     * executors using a handle associated with the main looper. When we are in an activity, we don't need
     * this main thread executor because we can use the run on UI Thread method. When we are in a
     * different class and we do not have the runOnUIThread() method, we can access the main thread
     * using this executor (It is difficult to imagine an example when we need this, see example
     * UDACITY, Android Development, Android Architecture Components
     */

    public Executor mainThread() {
        return mainThread;
    }

    /**
     * The networkIO Executor is a pool of three threads. This allows us to run different
     * network calls simultaneously while controlling the number or threads that we have.
     * @return networkIo Which Contains thread of pool size Three
     */
    public Executor networkIO() {
        return networkIO;
    }

    private static class MainThreadExecutor
            implements Executor
    {
        private final Handler mainThreadHandler = new Handler(Looper.getMainLooper());

        @Override
        public void execute(@NonNull Runnable command) {
            mainThreadHandler.post(command);
        }
    }
}
