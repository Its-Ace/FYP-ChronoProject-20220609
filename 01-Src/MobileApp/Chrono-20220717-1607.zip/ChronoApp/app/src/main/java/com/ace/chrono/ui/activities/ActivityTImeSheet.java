package com.ace.chrono.ui.activities;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ace.chrono.R;
import com.ace.chrono.constants.ConstantsRoomDatabase;
import com.ace.chrono.data.entities.TimeSheetEntry;
import com.ace.chrono.databinding.LayoutActivityTimeSheetBinding;
import com.ace.chrono.ui.adapters.AdapterActivityTimeSheetCheckInItem;
import com.ace.chrono.util.UtilAppBottomNavHelper;
import com.ace.horizontaldatepicker.HorizontalPicker;

import org.joda.time.DateTime;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ActivityTImeSheet extends AppCompatActivity
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private LayoutActivityTimeSheetBinding _binding;
    private ActivityTimeSheetViewModel _viewModel;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutActivityTimeSheetBinding.inflate( getLayoutInflater() );
        _viewModel = new ViewModelProvider( this ).get( ActivityTimeSheetViewModel.class );

        setContentView( _binding.getRoot() );

        UtilAppBottomNavHelper.init( _binding.activityTimeSheetBottomNavigation.appBottomNavigation,
                R.id.menu_activity_time_sheet );

        HorizontalPicker d = _binding.horizontalDatePicker;

        d.setDays( 120 )
                .setOffset( 7 )
                .setDateSelectedColor( Color.WHITE )
                .setDateSelectedTextColor( getResources().getColor( R.color.black ) )
                .setMonthAndYearTextColor( Color.DKGRAY )
                .setTodayButtonTextColor( getResources().getColor( R.color.primaryColor, getTheme() ) )
                .setTodayDateTextColor( getResources().getColor( R.color.primaryColor, getTheme() ) )
                .setTodayDateBackgroundColor( Color.GRAY )
                .setUnselectedDayTextColor( Color.DKGRAY )
                .setDayOfWeekTextColor( Color.DKGRAY )
                .setUnselectedDayTextColor( getResources().getColor( R.color.black ) )
                .showTodayButton( false ).init();

        d.setDate( DateTime.now() );
        d.setListener( dateSelected ->
        {
        } );


        dumpData();

        _viewModel.getTimeSheetEntries().subscribeOn( Schedulers.io() ).subscribe(
                new SingleObserver< List< TimeSheetEntry > >()
                {
                    @Override
                    public void onSubscribe( Disposable d )
                    {
                    }

                    @Override
                    public void onSuccess( List< TimeSheetEntry > timeSheetEntries )
                    {
                        AdapterActivityTimeSheetCheckInItem adap =
                                new AdapterActivityTimeSheetCheckInItem( timeSheetEntries,
                                        getApplicationContext() );

                        _binding.timeEntryRecyclerView.setAdapter( adap );
                        _binding.timeEntryRecyclerView.setLayoutManager(
                                new LinearLayoutManager( getApplicationContext() ) );
                    }

                    @Override
                    public void onError( Throwable e )
                    {

                    }
                } );
    }

    private void dumpData()
    {
        for ( int i = 0; i <= 30; i++ )
        {
            TimeSheetEntry entry = new TimeSheetEntry();

            entry._dataStatus = ConstantsRoomDatabase.STATUS_CREATED;
            entry._projectName = " Member " + i;

            _viewModel.addTimeEntryToRoomDatabase( entry );
        }
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}