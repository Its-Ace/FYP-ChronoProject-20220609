package com.ace.chrono.ui.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.R;
import com.ace.chrono.databinding.LayoutFragmentCreateSchedualeBinding;

public class FragmentCreateSchedule extends Fragment
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private FragmentCreateScheduleViewModel _viewModel;
    private LayoutFragmentCreateSchedualeBinding _binding;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _viewModel = new ViewModelProvider( this ).get( FragmentCreateScheduleViewModel.class );
        _binding = LayoutFragmentCreateSchedualeBinding.inflate( getLayoutInflater() );
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {

        return _binding.getRoot();
    }

    @SuppressLint( "NonConstantResourceId" )
    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );

        _binding.createScheduleWorkArrangmentRadioGroup.setOnCheckedChangeListener( ( radioGroup, i ) ->
        {
            switch ( i )
            {
                case R.id.create_schedule_fixed_btn:
                    _binding.createScheduleHrsFixedLayout.setVisibility( View.VISIBLE );

                    _binding.createScheduleHrsFlexibleLayout.setVisibility( View.GONE );
                    _binding.createScheduleHrsWeeklyLayout.setVisibility( View.GONE );
                    break;
                case R.id.create_schedule_flexible_btn:
                    _binding.createScheduleHrsFlexibleLayout.setVisibility( View.VISIBLE );

                    _binding.createScheduleHrsFixedLayout.setVisibility( View.GONE );
                    _binding.createScheduleHrsWeeklyLayout.setVisibility( View.GONE );

                    break;
                case R.id.create_schedule_weekly_btn:
                    _binding.createScheduleHrsWeeklyLayout.setVisibility( View.VISIBLE );

                    _binding.createScheduleHrsFixedLayout.setVisibility( View.GONE );
                    _binding.createScheduleHrsFlexibleLayout.setVisibility( View.GONE );
                    break;
            }
        } );

        _binding.createScheduleToolbar.setNavigationOnClickListener(
                view1 -> getParentFragmentManager().popBackStackImmediate() );
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}