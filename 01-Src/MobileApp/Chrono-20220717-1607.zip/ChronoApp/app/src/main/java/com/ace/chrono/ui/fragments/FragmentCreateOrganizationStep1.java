package com.ace.chrono.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.databinding.LayoutFragmentCreateOrganizationStep1Binding;

public class FragmentCreateOrganizationStep1 extends Fragment
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private FragmentCreateOrganizationStep1ViewModel mViewModel;
    private LayoutFragmentCreateOrganizationStep1Binding _binding;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    public void onCreate( @Nullable Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutFragmentCreateOrganizationStep1Binding.inflate( getLayoutInflater() );
        mViewModel =
                new ViewModelProvider( requireActivity() ).get(
                        FragmentCreateOrganizationStep1ViewModel.class );
    }

    @Override
    public View onCreateView( @NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState )
    {
        return _binding.getRoot();
    }

    @Override
    public void onViewCreated( @NonNull View view, @Nullable Bundle savedInstanceState )
    {
        super.onViewCreated( view, savedInstanceState );

        _binding.fragmentCreateOrganizationStep1ToNextStepBtn.setOnClickListener( v ->
        {
            FragmentCreateOrganizationStepTwo fragment = new FragmentCreateOrganizationStepTwo();
            String fragmentTag = fragment.getClass().getSimpleName();

            getParentFragmentManager()
                    .beginTransaction()
                    .addToBackStack( fragment.getClass().getSimpleName() )
                    .setReorderingAllowed( true )
                    .replace( _binding.fragmentContainer.getId(), fragment, fragmentTag )
                    .commit();
        } );
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}