package com.ace.chrono.ui.activities;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ace.chrono.R;
import com.ace.chrono.databinding.LayoutActivityTimeClockBinding;
import com.ace.chrono.util.UtilAppBottomNavHelper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.List;

public class ActivityTimeClock extends FragmentActivity
        implements OnMapReadyCallback
{
    ///////////////////////////////////////////
    // Members
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 16f;
    private static final int AUTOCOMPLETE_REQUEST_CODE = 1;
    private final String TAG = this.getClass().getSimpleName();
    private LayoutActivityTimeClockBinding _binding;
    private GoogleMap _map;
    private SupportMapFragment _mapFragment;
    private Boolean locationPermissionsGranted = false;
    private ActivityTimeClockViewModel _viewModel;

    ///////////////////////////////////////////
    // Constructors
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ///////////////////////////////////////////
    // Overrides
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );

        _binding = LayoutActivityTimeClockBinding.inflate( getLayoutInflater() );
        _viewModel = new ViewModelProvider( this ).get( ActivityTimeClockViewModel.class );
        _mapFragment = ( SupportMapFragment ) getSupportFragmentManager().findFragmentById(
                R.id.activity_clock_map_fragment );

        setContentView( _binding.getRoot() );

        UtilAppBottomNavHelper.init( _binding.activityTimeClockBottomNavView.appBottomNavigation,
                R.id.menu_activity_time_clock );

        takeLocationRequiredPermission();
    }

    @Override
    protected void onStart()
    {
        super.onStart();
    }

    ///////////////////////////////////////////
    // Methods
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    @Override
    public void onRequestPermissionsResult( int requestCode, @NonNull String[] permissions,
                                            @NonNull int[] grantResults )
    {
        super.onRequestPermissionsResult( requestCode, permissions, grantResults );

        locationPermissionsGranted = false;

        switch ( requestCode )
        {
            case LOCATION_PERMISSION_REQUEST_CODE:
            {
                if ( grantResults.length > 0 )
                {
                    for ( int i = 0; i < grantResults.length; i++ )
                    {
                        if ( grantResults[ i ] != PackageManager.PERMISSION_GRANTED )
                        {

                            locationPermissionsGranted = false;
                            return;
                        }
                    }

                    locationPermissionsGranted = true;
                }
            }
        }
    }

    @Override
    public void onMapReady( @NonNull GoogleMap googleMap )
    {

        _map = googleMap;

        getUserLocationFromGps();
    }

    private void takeLocationRequiredPermission()
    {
        String[] permissions = { Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION };

        if ( ContextCompat.checkSelfPermission( this, FINE_LOCATION ) ==
                PackageManager.PERMISSION_GRANTED )
        {
            if ( ContextCompat.checkSelfPermission( this, COURSE_LOCATION ) ==
                    PackageManager.PERMISSION_GRANTED )
            {
                locationPermissionsGranted = true;
                _mapFragment.getMapAsync( this );
            }
            else
            {
                ActivityCompat.requestPermissions( this,
                        permissions,
                        LOCATION_PERMISSION_REQUEST_CODE );
            }
        }
        else
        {
            ActivityCompat.requestPermissions( this,
                    permissions,
                    LOCATION_PERMISSION_REQUEST_CODE );
        }
    }

    @SuppressLint( "MissingPermission" )
    private void getUserLocationFromGps()
    {
        FusedLocationProviderClient locationProvider =
                LocationServices.getFusedLocationProviderClient(
                        this );
        try{
            if(locationPermissionsGranted)
            {
                final Task location = locationProvider.getLastLocation();

                location.addOnCompleteListener(new OnCompleteListener()
                {
                    @Override
                    public void onComplete(@NonNull Task task)
                    {
                        if(task.isSuccessful())
                        {
                            Log.d(TAG, "onComplete: found location!");

                            Location currentLocation = (Location) task.getResult();
                            LatLng userPosition = new LatLng(33.6169, 72.9720);

                            _map.clear();
                            _map.moveCamera(CameraUpdateFactory.newLatLngZoom(userPosition,DEFAULT_ZOOM));
                            MarkerOptions options = new MarkerOptions()
                                    .position(userPosition)
                                    .title("Your Location");
                            _map.addMarker(options);

                            Geocoder geocoder = new Geocoder(ActivityTimeClock.this);

                            try {

                                List<Address> addressesList = geocoder.getFromLocation(userPosition.latitude,userPosition.longitude,1);

                                _viewModel.setAddress(addressesList.get(0).getAddressLine(0));

                                Intent newIntent = new Intent();
                                newIntent.putExtra("USER_CURRENT_ADDRESS", _viewModel.getAddress());
                                setResult(RESULT_OK,newIntent);

                                Log.d(TAG, "onComplete: " + _viewModel.getAddress());

                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                        }
                        else{
                            Log.d(TAG, "onComplete: current location is null");
                        }
                    }
                });
            }
        }
        catch (SecurityException e)
        {
            Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage() );
        }
    }


    ///////////////////////////////////////////
    // End of class
    //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}