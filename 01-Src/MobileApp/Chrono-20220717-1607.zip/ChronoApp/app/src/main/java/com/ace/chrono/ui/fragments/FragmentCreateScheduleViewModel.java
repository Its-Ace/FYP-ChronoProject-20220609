package com.ace.chrono.ui.fragments;

import androidx.lifecycle.ViewModel;

public class FragmentCreateScheduleViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}